import java.util.ArrayList;
import java.util.List;

public abstract class Account {

    public static final String CHECKING = "CHECKING";
    public static final String SAVINGS = "SAVINGS";
    protected long accountNumber;
    protected double balance;
    protected List<Transaction> transactionList = new ArrayList<>();

    /**
     * A.
     */
    public Account() {

    }

    /**
     * A.
     */
    public Account(long accountNumber, double balance) {
        this.accountNumber = accountNumber;
        this.balance = balance;
    }

    /**
     * A.
     */
    public long getAccountNumber() {
        return accountNumber;
    }

    /**
     * A.
     */
    public void setAccountNumber(long accountNumber) {
        this.accountNumber = accountNumber;
    }

    /**
     * A.
     */
    public double getBalance() {
        return balance;
    }

    /**
     * A.
     */
    public void setBalance(double balance) {
        this.balance = balance;
    }

    /**
     * A.
     */
    public void doWithdrawing(double amount)
        throws InvalidFundingAmountException, InsufficientFundsException {
        if (amount < 0) {
            throw new InvalidFundingAmountException(amount);
        }

        if (amount > balance) {
            throw new InsufficientFundsException(amount);
        }

        balance -= amount;
    }

    /**
     * A.
     */
    public void doDepositing(double amount)
        throws InvalidFundingAmountException {
        if (amount < 0) {
            throw new InvalidFundingAmountException(amount);
        }
        balance += amount;
    }

    /**
     * A.
     */
    public abstract void withdraw(double amount);

    /**
     * A.
     */
    public abstract void deposit(double amount);

    /**
     * A.
     */
    public List<Transaction> getTransactionList() {
        return transactionList;
    }

    /**
     * A.
     */
    public void setTransactionList(List<Transaction> transactionList) {
        this.transactionList = transactionList;
    }

    /**
     * A.
     */
    public void addTransaction(Transaction transaction) {
        transactionList.add(transaction);
    }

    /**
     * A.
     */
    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Account) {
            return ((Account) obj).accountNumber == this.accountNumber;
        }
        return false;
    }

    /**
     * A.
     */
    public String getTransactionHistory() {
        String answer = "";
        answer += "Lịch sử giao dịch của tài khoản " + this.accountNumber + ":\n";
        for (Transaction transaction : transactionList) {
            answer += transaction.getTransactionSummary();
        }
        return answer;
    }
}
