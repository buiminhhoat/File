import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Bank {

    private List<Customer> customerList = new ArrayList<>();

    /**
     * A.
     */
    public List<Customer> getCustomerList() {
        return customerList;
    }

    /**
     * A.
     */
    public void setCustomerList(List<Customer> customerList) {
        this.customerList = customerList;
    }

    /**
     * A.
     */
    public void readCustomerList(InputStream inputStream) {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
        String line = null;
        while (true) {
            try {
                if (!((line = bufferedReader.readLine()) != null)) {
                    break;
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            if (line.charAt(0) >= '0' && line.charAt(0) <= '9') {
                if (line.charAt(11) == 'C') {
                    CheckingAccount checkingAccount = null;
                    Long accountNumber = Long.parseLong(line.substring(0, 10));
                    Double balance = Double.parseDouble(line.substring(20));
                    checkingAccount = new CheckingAccount(accountNumber, balance);
                    customerList.get(customerList.size() - 1).addAccount(checkingAccount);
                } else {
                    SavingsAccount savingsAccount = null;
                    Long accountNumber = Long.parseLong(line.substring(0, 10));
                    Double balance = Double.parseDouble(line.substring(19));
                    savingsAccount = new SavingsAccount(accountNumber, balance);
                    customerList.get(customerList.size() - 1).addAccount(savingsAccount);
                }
            } else {
                String fullName = line.substring(0, line.length() - 10);
                Long idNumber = Long.parseLong(line.substring(line.length() - 9));
                Customer customer = new Customer(idNumber, fullName);
                customerList.add(customer);
            }
        }
    }

    /**
     * A.
     */
    public String getCustomersInfoByNameOrder() {
        List<Customer> customers = new ArrayList<>();
        customers.addAll(customerList);
        Collections.sort(customers, new Comparator<Customer>() {
            @Override
            public int compare(Customer o1, Customer o2) {
                return o1.getFullName().compareTo(o2.getFullName());
            }
        });
        String answer = "";
        for (int i = 0; i < customers.size(); ++i) {
            answer += customers.get(i).getCustomerInfo();
            if (i != customers.size() - 1) {
                answer += "\n";
            }
        }
        return answer;
    }

    /**
     * A.
     */
    public String getCustomersInfoByIdOrder() {
        List<Customer> customers = new ArrayList<>();
        customers.addAll(customerList);
        Collections.sort(customers, new Comparator<Customer>() {
            @Override
            public int compare(Customer o1, Customer o2) {
                return Long.compare(o1.getIdNumber(), o2.getIdNumber());
            }
        });

        String answer = "";
        for (int i = 0; i < customers.size(); ++i) {
            answer += customers.get(i).getCustomerInfo();
            if (i != customers.size() - 1) {
                answer += "\n";
            }
        }
        return answer;
    }
}
