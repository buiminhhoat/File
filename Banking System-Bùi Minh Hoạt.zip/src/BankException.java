public abstract class BankException extends Exception {

    /**
     * A.
     */
    public BankException(String message) {
        super(message);
    }
}
