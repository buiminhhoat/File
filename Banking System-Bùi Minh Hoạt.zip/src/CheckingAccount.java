public class CheckingAccount extends Account {

    /**
     * A.
     */
    public CheckingAccount(long accountNumber, double balance) {
        super(accountNumber, balance);
    }

    /**
     * A.
     */
    @Override
    public void deposit(double amount) {
        try {
            transactionList.add(new Transaction(Transaction.TYPE_DEPOSIT_CHECKING,
                amount, balance, balance + amount));
            doDepositing(amount);
        } catch (Exception exception) {
            System.out.println(exception.getMessage());
        }
    }

    /**
     * A.
     */
    @Override
    public void withdraw(double amount) {
        try {
            transactionList.add(new Transaction(Transaction.TYPE_WITHDRAW_CHECKING,
                amount, balance, balance - amount));
            doWithdrawing(amount);
        } catch (Exception exception) {
            System.out.println(exception.getMessage());
        }
    }
}
