import java.util.ArrayList;
import java.util.List;

public class Customer {

    private long idNumber;
    private String fullName;
    private List<Account> accountList = new ArrayList<>();

    /**
     * A.
     */
    public Customer() {

    }

    /**
     * A.
     */
    public Customer(long idNumber, String fullName) {
        this.idNumber = idNumber;
        this.fullName = fullName;
    }

    /**
     * A.
     */
    public String getCustomerInfo() {
        return "Số CMND: " + idNumber + ". Họ tên: "
            + fullName + ".";
    }

    /**
     * A.
     */
    public void addAccount(Account account) {
        accountList.add(account);
    }

    /**
     * A.
     */
    public void removeAccount(Account account) {
        for (int i = 0; i < accountList.size(); ++i) {
            if (accountList.get(i).equals(account)) {
                accountList.remove(i);
                --i;
            }
        }
    }

    /**
     * A.
     */
    public long getIdNumber() {
        return idNumber;
    }

    /**
     * A.
     */
    public void setIdNumber(long idNumber) {
        this.idNumber = idNumber;
    }

    /**
     * A.
     */
    public String getFullName() {
        return fullName;
    }

    /**
     * A.
     */
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    /**
     * A.
     */
    public List<Account> getAccountList() {
        return accountList;
    }

    /**
     * A.
     */
    public void setAccountList(List<Account> accountList) {
        this.accountList = accountList;
    }
}
