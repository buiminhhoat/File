public class SavingsAccount extends Account {

    /**
     * A.
     */
    public SavingsAccount(long accountNumber, double balance) {
        super(accountNumber, balance);
    }

    /**
     * A.
     */
    @Override
    public void deposit(double amount) {
        try {
            transactionList.add(new Transaction(Transaction.TYPE_DEPOSIT_SAVINGS,
                amount, balance, balance + amount));
            doDepositing(amount);
        } catch (Exception exception) {
            System.out.println(exception.getMessage());
        }
    }

    /**
     * A.
     */
    @Override
    public void withdraw(double amount) {
        try {
            if (amount > 1000) {
                throw new InvalidFundingAmountException(amount);
            }

            if (balance < 5000) {
                throw new InsufficientFundsException(5000);
            }

            transactionList.add(new Transaction(Transaction.TYPE_WITHDRAW_SAVINGS,
                amount, balance, balance - amount));
            doWithdrawing(amount);
        } catch (Exception exception) {
            System.out.println(exception.getMessage());
        }
    }
}
