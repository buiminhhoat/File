public class Transaction {

    public static final int TYPE_DEPOSIT_CHECKING = 1;
    public static final int TYPE_WITHDRAW_CHECKING = 2;
    public static final int TYPE_DEPOSIT_SAVINGS = 3;
    public static final int TYPE_WITHDRAW_SAVINGS = 4;
    private int type;
    private double amount;
    private double initialBalance;
    private double finalBalance;

    /**
     * A.
     */
    public Transaction(int type, double amount, double initialBalance, double finalBalance)
        throws InvalidFundingAmountException, InsufficientFundsException {
        if (amount < 0) {
            throw new InvalidFundingAmountException(amount);
        }

        if (type == TYPE_WITHDRAW_SAVINGS) {
            if (amount > 1000) {
                throw new InvalidFundingAmountException(amount);
            }

            if (initialBalance < 5000) {
                throw new InsufficientFundsException(5000);
            }
        }

        if ((type == TYPE_WITHDRAW_SAVINGS || type == TYPE_WITHDRAW_CHECKING)
            && amount > initialBalance) {
            throw new InsufficientFundsException(amount);
        }

        this.type = type;
        this.amount = amount;
        this.initialBalance = initialBalance;
        this.finalBalance = finalBalance;
    }

    /**
     * A.
     */
    public int getType() {
        return type;
    }

    /**
     * A.
     */
    public void setType(int type) {
        this.type = type;
    }

    /**
     * A.
     */
    public double getAmount() {
        return amount;
    }

    /**
     * A.
     */
    public void setAmount(double amount) {
        this.amount = amount;
    }

    /**
     * A.
     */
    public double getInitialBalance() {
        return initialBalance;
    }

    /**
     * A.
     */
    public void setInitialBalance(double initialBalance) {
        this.initialBalance = initialBalance;
    }

    /**
     * A.
     */
    public double getFinalBalance() {
        return finalBalance;
    }

    /**
     * A.
     */
    public void setFinalBalance(double finalBalance) {
        this.finalBalance = finalBalance;
    }

    /**
     * A.
     */
    public String getTransactionTypeString(int transactionType) {
        if (transactionType == TYPE_DEPOSIT_CHECKING) {
            return "Nạp tiền vãng lai";
        }
        if (transactionType == TYPE_WITHDRAW_CHECKING) {
            return "Rút tiền vãng lai";
        }
        if (transactionType == TYPE_DEPOSIT_SAVINGS) {
            return "Nạp tiền tiết kiệm";
        }
        return "Rút tiền tiết kiệm";
    }

    /**
     * A.
     */
    public String getTransactionSummary() {
        return "- Kiểu giao dịch: " + getTransactionTypeString(this.type)
            + ". Số dư ban đầu: $" + String.format("%.2f", initialBalance)
            + ". Số tiền: $" + String.format("%.2f", amount)
            + ". Số dư cuối: $" + String.format("%.2f", finalBalance) + ".\n";
    }
}
